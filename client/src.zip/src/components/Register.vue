<template>
    <!-- Material form register -->
    <div class="col-6 offset-3">

        <div class="card">

            <h5 class="card-header info-color white-text text-center py-4">
                <strong>Sign up</strong>
            </h5>

            <!--Card content-->

            <div class="card-body px-lg-5 pt-0">

                <!-- Form -->
                <form class="text-center" style="color: #757575;">

                    <div class="form-row">
                        <div class="col">
                            <!-- First name -->
                            <div class="md-form">
                                <input
                                    type="text"
                                    id="materialRegisterFormFirstName"
                                    class="form-control">
                                <label for="materialRegisterFormFirstName">First name</label>
                            </div>
                        </div>
                        <div class="col">
                            <!-- Last name -->
                            <div class="md-form">
                                <input
                                    type="email"
                                    id="materialRegisterFormLastName"
                                    class="form-control">
                                <label for="materialRegisterFormLastName">Last name</label>
                            </div>
                        </div>
                    </div>

                    <!-- E-mail -->
                    <div class="md-form mt-0">
                        <input type="email" id="materialRegisterFormEmail" class="form-control">
                        <label for="materialRegisterFormEmail">E-mail</label>
                    </div>

                    <!-- Password -->
                    <div class="md-form">
                        <input
                            type="password"
                            id="materialRegisterFormPassword"
                            class="form-control"
                            aria-describedby="materialRegisterFormPasswordHelpBlock">
                        <label for="materialRegisterFormPassword">Password</label>
                        <small
                            id="materialRegisterFormPasswordHelpBlock"
                            class="form-text text-muted mb-4">
                            At least 8 characters and 1 digit
                        </small>
                    </div>

                    <!-- Phone number -->


                    <!-- Newsletter -->


                    <!-- Sign up button -->
                    <button
                        class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0"
                        type="submit">
                        Sign Up
                    </button>

                    <!-- Social register -->
                    <p>or sign up with:</p>

                    <a type="button" class="btn-floating btn-fb btn-sm">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a type="button" class="btn-floating btn-tw btn-sm">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a type="button" class="btn-floating btn-li btn-sm">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a type="button" class="btn-floating btn-git btn-sm">
                        <i class="fab fa-github"></i>
                    </a>

                    <hr>


                </form>
                <!-- Form -->

            </div>

        </div>
    </div>
    <!-- Material form register -->
</template>


<script>
export default {
  name: 'Register',
};
</script>


<style scoped>
.card {
    margin-top: 8%;
}
</style>
